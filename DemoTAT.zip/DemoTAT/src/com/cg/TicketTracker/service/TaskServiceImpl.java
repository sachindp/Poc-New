package com.cg.TicketTracker.service;

import java.util.List;

import com.cg.TicketTracker.dao.ITaskDAO;
import com.cg.TicketTracker.dao.TaskDAOImpl;
import com.cg.TicketTracker.dto.Task;
import com.cg.TicketTracker.exception.TaskException;

public class TaskServiceImpl implements ITaskService{

	private ITaskDAO taskDAO;
	
	public TaskServiceImpl() {
		taskDAO = new TaskDAOImpl();
	}

	@Override
	public int addTask(Task task) throws TaskException {
		return taskDAO.addTask(task);
	}

	@Override
	public void updateTask(Task task) throws TaskException {
		taskDAO.updateTask(task);
	}

	@Override
	public Task removeTask(int taskId) throws TaskException {
		return taskDAO.removeTask(taskId);
	}

	@Override
	public Task viewTask(int taskId) throws TaskException {
		return taskDAO.viewTask(taskId);
	}

	@Override
	public List<Task> viewAllTasks() throws TaskException {
		return taskDAO.viewAllTasks();
	}

	@Override
	public void login(String username, String password) throws TaskException {
		taskDAO.login(username, password);
		
	}

}
