package com.cg.TicketTracker.controller;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.TicketTracker.dto.Task;
import com.cg.TicketTracker.exception.TaskException;
import com.cg.TicketTracker.service.ITaskService;
import com.cg.TicketTracker.service.TaskServiceImpl;

@WebServlet("/TaskController")
public class TaskContoller extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ITaskService taskService;
	
	public TaskContoller() {
		taskService=new TaskServiceImpl();
		}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		processRequest(request,response);	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		processRequest(request,response);
	}
	
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String action =request.getParameter("action");
		//System.out.println(action);
		
		switch(action)
		{
			case "addTask":
				String appName=request.getParameter("appName");
				String taskName=request.getParameter("taskName");
				String taskDesc=request.getParameter("taskDesc");
				String startDate=request.getParameter("startDate");
				String endDate=request.getParameter("endDate");
				String status=request.getParameter("status");
				String priority=request.getParameter("priority");
				String offshoreOwner=request.getParameter("offshoreOwner");
				String onshoreOwner=request.getParameter("onshoreOwner");
				String comments=request.getParameter("comments");
				String createdBy=request.getParameter("createdBy");
				String createdOn=request.getParameter("createdOn");
				String updatedBy=request.getParameter("updatedBy");
				String updatedOn=request.getParameter("updatedOn");

				Task task=new Task();
				task.setAppName(appName);
				task.setTaskName(taskName);
				task.setTaskDesc(taskDesc);
				
				DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
				LocalDate ld1= LocalDate.parse(startDate,formatter1);
				Date date1=java.sql.Date.valueOf(ld1);
				task.setStartDate(date1);
				
				DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
				LocalDate ld2= LocalDate.parse(endDate,formatter2);
				Date date2=java.sql.Date.valueOf(ld2);
				task.setEndDate(date2);
				
				task.setStatus(status);
				task.setPriority(priority);
				task.setOffshoreOwner(offshoreOwner);
				task.setOnshoreOwner(onshoreOwner);
				task.setComments(comments);
				task.setCreatedBy(createdBy);
				
				DateTimeFormatter formatter3 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
				LocalDate ld3= LocalDate.parse(createdOn,formatter3);
				Date date3=java.sql.Date.valueOf(ld3);
				task.setCreatedOn(date3);
				
				task.setUpdatedBy(updatedBy);
				
				DateTimeFormatter formatter4 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
				LocalDate ld4= LocalDate.parse(updatedOn,formatter4);
				Date date4=java.sql.Date.valueOf(ld4);
				task.setUpdatedOn(date4);
			
				RequestDispatcher rd= null;
				
				try
				{
					int taskId=taskService.addTask(task);
					
					request.setAttribute("taskId", taskId);
					
					rd=request.getRequestDispatcher("AddTask.jsp");
				}
				catch(TaskException e)
				{
					request.setAttribute("errMsg", "Something went wrong while trying to add task details..Reason"+e.getMessage());
					rd=request.getRequestDispatcher("ErrorPage.jsp");
				}
				
				rd.forward(request, response);
				return;
			case "viewTaskDetailsForUpdate":
				String idStr = request.getParameter("taskId");
				
				try
				{
					task=taskService.viewTask(Integer.parseInt(idStr));
					
					request.setAttribute("Task",task);
					rd=request.getRequestDispatcher("UpdateTask.jsp");
				}
				catch(TaskException e)
				{
					request.setAttribute("errMsg", "Something went wrong while trying to fetch task details for update..Reason"+e.getMessage());
					rd=request.getRequestDispatcher("ErrorPage.jsp");
				}
				
				rd.forward(request, response);
				
				return;
				
			case "updateTask":
				
				String taskId=request.getParameter("taskId");
				appName=request.getParameter("appName");
				taskName=request.getParameter("taskName");
				taskDesc=request.getParameter("taskDesc");
				startDate=request.getParameter("startDate");
				endDate=request.getParameter("endDate");
				status=request.getParameter("status");
				priority=request.getParameter("priority");
				offshoreOwner=request.getParameter("offshoreOwner");
				onshoreOwner=request.getParameter("onshoreOwner");
				comments=request.getParameter("comments");
				createdBy=request.getParameter("createdBy");
				createdOn=request.getParameter("createdOn");
				updatedBy=request.getParameter("updatedBy");
				updatedOn=request.getParameter("updatedOn");
				
				task=new Task();
				
				task.setTaskId(Integer.parseInt(taskId));
				task.setAppName(appName);
				task.setTaskName(taskName);
				task.setTaskDesc(taskDesc);
				
				formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				ld1=LocalDate.parse(startDate,formatter1);
				date1=java.sql.Date.valueOf(ld1);
				task.setStartDate(date1);
				
				formatter2 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				ld2=LocalDate.parse(endDate,formatter2);
				date2=java.sql.Date.valueOf(ld2);
				task.setEndDate(date2);
				
				task.setStatus(status);
				task.setPriority(priority);
				task.setOffshoreOwner(offshoreOwner);
				task.setOnshoreOwner(onshoreOwner);
				task.setComments(comments);
				task.setCreatedBy(createdBy);
				
				formatter3 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				ld3=LocalDate.parse(createdOn,formatter3);
				date3=java.sql.Date.valueOf(ld3);
				task.setCreatedOn(date3);
				
				formatter4 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				ld4=LocalDate.parse(updatedOn,formatter4);
				date4=java.sql.Date.valueOf(ld4);
				task.setUpdatedOn(date4);
				
				rd= null;
				
				
				try
				{
					taskService.updateTask(task);
					
					request.setAttribute("taskId", task.getTaskId());
					rd=request.getRequestDispatcher("UpdateTask.jsp");
				}
				catch(TaskException e)
				{
					request.setAttribute("errMsg", "Something went wrong while trying to updateing task details..Reason"+e.getMessage());
					rd=request.getRequestDispatcher("ErrorPage.jsp");
				}
				
				rd.forward(request, response);
				
				return;
			case "removeTask":
				idStr = request.getParameter("taskId");
				
				try
				{
					task=taskService.removeTask(Integer.parseInt(idStr));
					request.setAttribute("Task",task);
					rd=request.getRequestDispatcher("RemoveTask.jsp");
				}
				catch(TaskException e)
				{
					request.setAttribute("errMsg", "Something went wrong while trying to remove task details..Reason"+e.getMessage());
					rd=request.getRequestDispatcher("ErrorPage.jsp");
				}
				
				rd.forward(request, response);
				
			case "ViewTask":
				idStr = request.getParameter("taskId");
				
				try
				{
					task=taskService.viewTask(Integer.parseInt(idStr));
					request.setAttribute("Task",task);
					rd=request.getRequestDispatcher("ViewTask.jsp");
				}
				catch(TaskException e)
				{
					request.setAttribute("errMsg", "Something went wrong while trying to fetch task details..Reason"+e.getMessage());
					rd=request.getRequestDispatcher("ErrorPage.jsp");
				}
				
				rd.forward(request, response);
				
			case "ViewAllTasks":
				
				rd=null;
				
				try
				{
					List<Task> tasks=taskService.viewAllTasks();
					
					request.setAttribute("tasks", tasks);
					
					rd=request.getRequestDispatcher("ViewAllTasks.jsp");
					
					
				}
				catch(TaskException e)
				{
					request.setAttribute("errMsg", "Something went wrong while trying to add task details..Reason"+e.getMessage());
					rd=request.getRequestDispatcher("ErrorPage.jsp");
				}
				
				rd.forward(request, response);
				
				return;
			default: 
				break;
	}
	
	}
}
