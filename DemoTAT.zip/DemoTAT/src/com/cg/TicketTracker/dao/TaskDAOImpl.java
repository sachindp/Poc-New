package com.cg.TicketTracker.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.TicketTracker.dto.Task;
import com.cg.TicketTracker.exception.TaskException;
import com.cg.TicketTracker.util.DBUtil;

public class TaskDAOImpl implements ITaskDAO {

	@Override
	public int addTask(Task task) throws TaskException {
		
		int taskId;
		
		try(Connection conn = DBUtil.getConnection())
		{
			
			//Statement stm = conn.createStatement();
			
			//ResultSet res = stm.executeQuery("select pro_id_seq.NEXTVAL from dual");
			
			/*if(res.next() == false)
			{
				throw new Exception("Failed to Generate Task ID");
			}*/
			
			//task.setTaskId(res.getInt(1));
						
			PreparedStatement pstm = 
					conn.prepareStatement("insert into taskdetails(appName,taskName,taskDesc,startDate,endDate,status,priority,offshoreOwner,onshoreOwner,comments,createdBy,createdOn,updatedBy,updatedOn) "
							+ "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			
			//pstm.setInt(1, task.getTaskId());
			pstm.setString(1, task.getAppName());
			pstm.setString(2, task.getTaskName());
			pstm.setString(3, task.getTaskDesc());
			
			long value1 = task.getStartDate().getTime();//convert util date to long value
			java.sql.Date sdate = new java.sql.Date(value1);//convert long value to sql date
			pstm.setDate(4,sdate);
			
			long value2 = task.getEndDate().getTime();//convert util date to long value
			java.sql.Date edate = new java.sql.Date(value2);//convert long value to sql date
			pstm.setDate(5,edate);
			
			pstm.setString(6, task.getStatus());
			pstm.setString(7, task.getPriority());
			pstm.setString(8, task.getOffshoreOwner());
			pstm.setString(9, task.getOnshoreOwner());
			pstm.setString(10, task.getComments());
			pstm.setString(11, task.getCreatedBy());
			
			long value3 = task.getCreatedOn().getTime();//convert util date to long value
			java.sql.Date codate = new java.sql.Date(value3);//convert long value to sql date
			pstm.setDate(12,codate);
			
			pstm.setString(13, task.getUpdatedBy());
			
			long value4 = task.getUpdatedOn().getTime();//convert util date to long value
			java.sql.Date uodate = new java.sql.Date(value4);//convert long value to sql date
			pstm.setDate(14,uodate);
			
			pstm.execute();
			
			taskId= task.getTaskId();//return the task id generated
			
		}
		catch(Exception e)
		{
			throw new TaskException(e.getMessage());
		}
		
		return taskId;
	}

	@Override
	public void updateTask(Task task) throws TaskException {
		try(Connection conn = DBUtil.getConnection())
		{
			PreparedStatement pstm = 
					conn.prepareStatement("update taskdetails "+"set appName=?, taskName=?, taskDesc=?, "
							+ "startDate=?, endDate=?, status=?, priority=?, offshoreOwner=?, "
							+ "onshoreOwner=?, comments=?, createdBy=?, createdOn=?, "
							+ "updatedBy=?, updatedOn=? where taskId=? ");
			
			pstm.setString(1, task.getAppName());
			pstm.setString(2, task.getTaskName());
			pstm.setString(3, task.getTaskDesc());
			
			long value1 = task.getStartDate().getTime();//convert util date to long date
			java.sql.Date sdate = new java.sql.Date(value1);//conert lonbg value to sql date
			pstm.setDate(4, sdate);
			
			long value2 = task.getEndDate().getTime();//convert util date to long date
			java.sql.Date edate = new java.sql.Date(value2);//conert lonbg value to sql date
			pstm.setDate(5, edate);
			
			pstm.setString(6, task.getStatus());
			pstm.setString(7, task.getPriority());
			pstm.setString(8, task.getOffshoreOwner());
			pstm.setString(9, task.getOnshoreOwner());
			pstm.setString(10, task.getComments());
			pstm.setString(11, task.getCreatedBy());

			long value3 = task.getCreatedOn().getTime();//convert util date to long date
			java.sql.Date codate = new java.sql.Date(value3);//conert lonbg value to sql date
			pstm.setDate(12, codate);
			
			pstm.setString(13, task.getUpdatedBy());

			long value4 = task.getUpdatedOn().getTime();//convert util date to long date
			java.sql.Date uodate = new java.sql.Date(value4);//conert lonbg value to sql date
			pstm.setDate(14, uodate);
			pstm.setInt(15, task.getTaskId());
			pstm.execute();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new TaskException(e.getMessage());
		}

	}


	@Override
	public Task removeTask(int taskId) throws TaskException {
		Task task=null;
		
		try(Connection conn = DBUtil.getConnection())
		{
			PreparedStatement pstm = conn.prepareStatement("select * from taskdetails where taskId=?");
			pstm.setInt(1, taskId);
			
			ResultSet res = pstm.executeQuery();
			
			if(res.next() == false)//no row in resultset hence
			{
				throw new Exception("No product found with id= "+taskId);
				
			}
			task=new Task();
			
			task.setTaskId(res.getInt(1));
			task.setAppName(res.getString(2));
			task.setTaskName(res.getString(3));
			task.setTaskDesc(res.getString(4));
			task.setStartDate(res.getDate(5));
			task.setEndDate(res.getDate(6));
			task.setStatus(res.getString(7));
			task.setPriority(res.getString(8));
			task.setOffshoreOwner(res.getString(9));
			task.setOnshoreOwner(res.getString(10));
			task.setComments(res.getString(11));
			task.setCreatedBy(res.getString(12));
			task.setCreatedOn(res.getDate(13));
			task.setUpdatedBy(res.getString(14));
			task.setUpdatedOn(res.getDate(15));
						
			//remove product
			PreparedStatement pstm2 = conn.prepareStatement("delete from taskdetails where taskId=?");
			pstm2.setInt(1, taskId);
			pstm2.execute();
			
		}
		catch(Exception e)
		{
			throw new TaskException(e.getMessage());
		}
		return task;
	}

	@Override
	public Task viewTask(int taskId) throws TaskException {
		Task task=null;
				
		try(Connection conn = DBUtil.getConnection())
		{
			PreparedStatement pstm = conn.prepareStatement("select * from taskdetails where taskId=?");
			pstm.setInt(1, taskId);
			
			ResultSet res = pstm.executeQuery();
			
			if(res.next() == false)
			{
				throw new Exception("No task found with id= "+taskId);
				
			}
			task=new Task();
			
			task.setTaskId(res.getInt(1));
			task.setAppName(res.getString(2));
			task.setTaskName(res.getString(3));
			task.setTaskDesc(res.getString(4));
			task.setStartDate(res.getDate(5));
			task.setEndDate(res.getDate(6));
			task.setStatus(res.getString(7));
			task.setPriority(res.getString(8));
			task.setOffshoreOwner(res.getString(9));
			task.setOnshoreOwner(res.getString(10));
			task.setComments(res.getString(11));
			task.setCreatedBy(res.getString(12));
			task.setCreatedOn(res.getDate(13));
			task.setUpdatedBy(res.getString(14));
			task.setUpdatedOn(res.getDate(15));
						
		} catch(Exception e)
		{
			throw new TaskException(e.getMessage());
		}
		
		return task;
	}

	@Override
	public List<Task> viewAllTasks() throws TaskException {
		
		List<Task> tasks= null;
		
		try(Connection conn = DBUtil.getConnection())
		{
			Statement stm = conn.createStatement();
			
			ResultSet res = stm.executeQuery("select * from taskdetails");
			
			tasks = new ArrayList<Task>();
			
			while(res.next())
			{
				Task currentTask = new Task();
				
				currentTask.setTaskId(res.getInt(1));
				currentTask.setAppName(res.getString(2));
				currentTask.setTaskName(res.getString(3));
				currentTask.setTaskDesc(res.getString(4));
				currentTask.setStartDate(res.getDate(5));
				currentTask.setEndDate(res.getDate(6));
				currentTask.setStatus(res.getString(7));
				currentTask.setPriority(res.getString(8));
				currentTask.setOffshoreOwner(res.getString(9));
				currentTask.setOnshoreOwner(res.getString(10));
				currentTask.setComments(res.getString(11));
				currentTask.setCreatedBy(res.getString(12));
				currentTask.setCreatedOn(res.getDate(13));
				currentTask.setUpdatedBy(res.getString(14));
				currentTask.setUpdatedOn(res.getDate(15));
				
				tasks.add(currentTask);
				
			}
		}
		catch(Exception e)
		{
			throw new TaskException(e.getMessage());
		}
		
		return tasks;
	}

	@Override
	public void login(String username, String password) throws TaskException{
		boolean loginStatus=false;
		try(Connection conn = DBUtil.getConnection())
		{
			PreparedStatement pstm1 = conn.prepareStatement("select * from taskdetails where empId=? and password=?");
			pstm1.setString(1, username);
			pstm1.setString(2, password);
			
			ResultSet res = pstm1.executeQuery();
			loginStatus=res.next();
			if(loginStatus==true)
			{
				
			}
		}
		catch(Exception e)
		{
			throw new TaskException(e.getMessage());
		}
	}

}
